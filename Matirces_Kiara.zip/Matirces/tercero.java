package Matirces;

public class tercero {
    public static void main(String[] args) {
        int[][] notas = {
                {5, 7, 8},
                {6, 9, 7},
                {8, 8, 10}
        };
        // Notas del primer alumno, segundo alumno y el tercero alumno

        System.out.println(notas[0][0]); // 5
        System.out.println(notas[1][2]); // 7
        System.out.println(notas[2][1]); // 8
    }

    int[][] edad = new int[4][4];

    int [][] num = {
            {}
    };

}

