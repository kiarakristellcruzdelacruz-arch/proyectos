package Matirces;

public class Primero {
    public static void main(String[] args) {
        int [][] notas = {
                {7,8,6},
                {5,6,7},
                {9,8,10}
        };
        // Mostrar la matriz con dos for anidados
//        System.out.println("Matriz original:");
//        for (int fila = 0; fila < notas.length; fila++) {
//            for (int columna = 0; columna < notas[fila].length; columna++) {
//                System.out.print(notas[fila][columna] + " ");
//            }
//            System.out.println();
//        }
//        // Mostrar la diagonal principal
//        System.out.println("Diagonal principal:");
//        for (int fila = 0; fila < notas.length; fila++) {
//            for (int columna = 0; columna < notas[fila].length; columna++) {
//                if (fila == columna) {
//                    System.out.print(notas[fila][columna] + " ");
//                }
//            }
//        }
//        // Mostrar la matriz modificada
//        System.out.println("Matriz modificada:");
//        for (int fila = 0; fila < notas.length; fila++) {
//            for (int columna = 0; columna < notas[fila].length; columna++) {
//                System.out.print(notas[fila][columna] + " ");
//            }
//            System.out.println();
//        }
        // Cambiar el primer elemento
        notas[0][0] = 20;
        System.out.println(notas[0][0]); // 7
        System.out.println(notas[1][1]); // 6
        System.out.println(notas[2][2]); // 10

    }
}

