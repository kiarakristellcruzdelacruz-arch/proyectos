package Matirces;

public class segundo {
    public static void main(String[] args) {
        int[][] numeros = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
//        for (int fila = 0; fila < numeros.length; fila++) {
//            for (int columna = 0; columna < numeros[fila].length; columna++) {
//                System.out.print(numeros[fila][columna] + " ");
//            }
//            System.out.println();
        System.out.println(numeros[0][0]); // 1
        System.out.println(numeros[1][2]); // 6
        System.out.println(numeros[2][0]); // 7
        System.out.println(numeros[2][2]); // 9

//        }
    }
}

