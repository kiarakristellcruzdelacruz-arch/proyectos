package Matirces;

public class cuarto {
    public static void main(String[] args) {
        int [][] matriz = {
                {10, 20, 20},
                {40,50,60}
        };
        System.out.println(matriz.length);
        System.out.println(matriz[0].length);
    }
}
