package Matirces;

public class prueba {

    public static void main(String[] args) {
        boolean [][] sala =  new boolean[5][5];

        // 1. Asientos ocupados aleatoriamente.
        for (int fila = 0; fila < sala.length; fila++) {
            for (int columna = 0; columna < sala[fila].length; columna++) {
                sala[fila][columna] = Math.random() < 0.4; // true u ocupado, false libre
            }
        }

        // 2. Mostrar mapa visual
        System.out.println("Mapa Visual de la Sala");
        int libres = 0;

        for (int fila = 0; fila < sala.length; fila++) {
            for (int columna = 0; columna < sala[fila].length; columna++) {

                if (sala[fila][columna]) {
                    System.out.print("[X]");
                } else {
                    System.out.print("[ ]");
                    libres++;
                }
            }
            System.out.println();
        }

        // 3. Mostrar total de asientos libres
        System.out.println("sientos libres: " + libres);

        // 4. Comprobar filas completamente vacías
        boolean hayFilaVacia = false;

        for (int fila = 0; fila < sala.length; fila++) {
            boolean filaVacia = true;

            for (int columna = 0; columna < sala[fila].length; columna++) {
                if (sala[fila][columna]) {
                    filaVacia = false;
                    break;
                }
            }

            if (filaVacia) {
                System.out.println("La fila " + (fila + 1) + " está completamente vacía.");
                hayFilaVacia = true;
            }
        }
        if (!hayFilaVacia) {
            System.out.println("No hay ninguna fila completamente vacía.");
        }

    }
}
