package Matirces;

public class repaso {
    public static void main(String[] args) {
        int[][] datos = {
                {5, 10, 15, 20},
                {25, 30, 35, 40}
        };
        System.out.println(datos.length);
        System.out.println(datos[0].length);

        //Cuanto vale cada dato

        System.out.println(datos[1][3]);
        System.out.println(datos[0][2]);
    }
}
